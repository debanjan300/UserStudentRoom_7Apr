import { Component, DoCheck, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-room',
  templateUrl: './room.component.html',
  styleUrls: ['./room.component.css']
})
export class RoomComponent implements OnInit, DoCheck {
  role:string="";
  roomForm:any;
  rooms:any;
  constructor(private fb:FormBuilder, private rs:RoomService) { 
    this.roomForm=this.fb.group({
      roomId:[''],
      roomType:[''],
      roomOccupancy:[''],
      fee:[''],
      bookingStatus:['Available']
    });
  }
  ngDoCheck(): void {
    var strRole= localStorage.getItem("loggedRole");
    if(strRole!=null)
      this.role=strRole;
      else
        this.role="";
    console.log("Room component do check method:"+this.role);
    

  }

  ngOnInit(): void {
    this.loadRooms();
  }

  loadRooms()
{
  this.rs.getAllRooms().subscribe((data)=>{
    console.log(data);
    this.rooms=data;

  });
}
fnAdd()
{
  var room=this.roomForm.value;
    this.rs.addRoom(room).subscribe((data)=>{
      console.log(data);
      this.loadRooms();
    });
}
fnModify()
{
  var room=this.roomForm.value;
    this.rs.modifyRoom(room).subscribe((data)=>{
      console.log(data);
      this.loadRooms();
    });
}
fnDelete()
{
  var roomId=this.roomForm.controls.roomId.value;
   // alert(roomId);
    this.rs.deleteRoom(roomId).subscribe((data)=>{
      console.log(data);
      this.loadRooms();
    });
}

}
