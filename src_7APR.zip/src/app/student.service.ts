import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  url:string='http://localhost:8080/student/';

  constructor(private http:HttpClient) { }
  getAllStudents()
  {
    return this.http.get(this.url);
  }

  findStudentById(studentId:any)
  {
    return this.http.get(this.url+studentId);
  }

  addStudent(student:any)
  {
    return this.http.post(this.url,student);
  }

  modifyStudent(student:any)
  {
    return this.http.put(this.url,student);
  }

  deleteStudent(studentId:any)
  {
    return this.http.delete(this.url+studentId);
  }
 

}
