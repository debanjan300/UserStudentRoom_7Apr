import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { BranchComponent } from './branch/branch.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { MenuComponent } from './menu/menu.component';
import { RoomComponent } from './room/room.component';
import { SignupComponent } from './signup/signup.component';
import { StudentComponent } from './student/student.component';

const routes: Routes = [
  {path:'home',component:HomeComponent, outlet: 'col3'},
  {path:'branch',component:BranchComponent, outlet: 'col2'},
{path:'contact',component:ContactUsComponent, outlet: 'col1'},
{path:'about',component:AboutUsComponent, outlet: 'col1'},
{path:'Login',component:LoginComponent, outlet: 'col3'},
{path:'signup',component:SignupComponent, outlet: 'col3'},
{path:'Logout',component:LogoutComponent, outlet: 'col3'},
{path:'menu',component:MenuComponent},
{path:'room',component:RoomComponent, outlet: 'col2'},
{path:'student',component:StudentComponent, outlet: 'col2'}

];

@NgModule({
  imports: [RouterModule.forRoot(routes, {onSameUrlNavigation:'reload'})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
