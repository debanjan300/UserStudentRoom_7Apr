package com.example.demo.model;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Student;
import com.example.demo.entity.User;

@Repository
public interface StudentRepository extends JpaRepository<Student,Long> {
	@Query("select s from Student s where s.user.userName=:userName")
	public Student findStudentByUserName(@Param("userName")String userName);
	
	@Query("select u from User u JOIN Student s ON u.userName=s.user.userName WHERE s.studentId=:studentId")
	public User findUserByStudentId(@Param("studentId") Long studentId);
}
