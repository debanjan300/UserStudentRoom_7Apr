import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DoCheck, Input, OnInit } from '@angular/core';
import { LoginComponent } from '../login/login.component';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
  
})
export class MenuComponent implements DoCheck,OnInit {
  status:string;
  constructor() {
    this.status='Login';
    
   }

  ngOnInit(): void {
  
  }
  ngDoCheck() :void {
    this.refresh();
  }

  

  refresh()
  {
    
    var loggedUserName=localStorage.getItem("loggedUserName");
    // alert(loggedUserName)
    if(loggedUserName==null)
      this.status="Login";
    else
      this.status="Logout";
      // alert(this.status)
    // var userName=this.lc.loginForm.controls.userName.value;
    // if(userName!=null)
    //     this.status="Logout";
  }
}
